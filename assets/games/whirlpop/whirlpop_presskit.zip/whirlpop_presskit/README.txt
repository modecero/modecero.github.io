WHIRLPOP - PRESS KIT
Updated November 2026

FACTSHEET
---------
Developer:  Mode Cero (Spain)
Genre:      Puzzle / arcade
Platform:   HTML5 - mobile and desktop browsers
Languages:  English, Spanish, French, Italian, German
Status:     Finished - available for licensing and publishing
Contact:    hello@modecero.com
Website:    https://modecero.com

ONE LINE
--------
Falling blocks meet match-3 on a spinning board.

PITCH
-----
Whirlpop is a 100% original HTML5 puzzler that brings together two of the
most addictive genres ever made, falling blocks and match-3, by putting them
on a spinning board. It runs instantly on any device, mobile or desktop, and
is built for the endless "one more go."

FEATURES
--------
- Spin the pile to catch the falling balls; group 3 of a color to clear them.
- Hard drop at any moment to speed things up.
- Take too long and the balls turn to stone.
- White balls match any color.
- Fill the ring with matches and combos to unleash a bomb.
- Balls that weave across the board, side to side and top to bottom.
- Endless score chase with a personal best.

CONTROLS
--------
Touch:     drag to spin, tap to drop.
Desktop:   drag with the mouse or use the arrow keys / A-D to spin;
           click or press down to drop.

TECH
----
- Single self-contained HTML5 build, about 2.5 MB, no external requests.
- Targets 60 fps on mobile.
- Ad-ready: natural breaks between runs, side space for a banner on wide
  screens.

ABOUT MODE CERO
---------------
Mode Cero is an independent studio from Spain that makes original casual
games.

Website:  https://modecero.com
X:        https://x.com/Mode_Cero
YouTube:  https://www.youtube.com/channel/UCrcsM4LawGTwyH0Yw1BSk9w
TikTok:   https://www.tiktok.com/@mode_cero

CREDITS
-------
Game, music and sound design by Mode Cero.
Piano: Salamander Grand Piano V2 by Alexander Holm, CC BY 3.0.
Input prompts: Kenney (CC0).
Typeface: Baloo 2 (SIL Open Font License).

CONTENTS
--------
factsheet.pdf    This information, laid out.
logos/           Whirlpop wordmark (transparent PNG) and the Mode Cero logo
                 in three versions, each as SVG and PNG 4096 / 1024 px:
                 original (main use), flat (print and very small sizes) and
                 flat-inverse (for dark backgrounds).
key-art/         Clean key art (2048 x 2048, no logo) and covers with logo
                 (1920x1080, 1080x1620, 800x1200, 800x800).
screenshots/     Desktop (2K), Android and iPad Pro.
video/           Gameplay videos, landscape (1920x1080) and portrait
                 (1080x1620), 16 s, no audio.

USAGE
-----
All assets may be used for coverage, evaluation and promotion of Whirlpop.
Please don't alter the logos.
